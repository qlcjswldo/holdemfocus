package com.focus_0.focus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Focus0ApplicationTests {

	@Test
	void contextLoads() {
	}

}
