package com.focus_0.focus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Focus0Application {

	public static void main(String[] args) {
		SpringApplication.run(Focus0Application.class, args);
	}

}
